﻿<?php
	session_start();
	//demander à l'utilisateur de s'authentifier
	if (!$_SESSION['email']){
		header('Location: login.php');
		exit();
	}	
	
	require_once 'config.php';
	
?>
<!DOCTYPE html>
<html>
<meta charset="UTF-8">
<link rel="stylesheet" type="text/css" href="./style.css">
<?php
	include 'header.php';
?>
<head>
	<title>Commande N <<?php echo $_GET['commande_id'];?></title>
</head>
<body>

	<div align="center"> <!-- début contenu -->	
	<h2 align="center">Commande Numéro <?php echo $_GET['commande_id'];?></h2>
	
	<?php					
		//Récupérer les items correspondant à order_id et les afficher 
		$query = "SELECT produit.produit_id, produit.produit_name, item.item_quantity, item.item_price FROM produit, item WHERE produit.produit_id = item.item_produit AND item.item_commande='".$_GET['commande_id']."'";		
		$result = mysqli_query($con,$query);
		//afficher les enregistrements de la table
		echo "<table align=\"center\" class=\"list\">";
		echo "<th>Bière</th><th></th><th></th><th>Quantité</th><th>Prix</th>";
		while($row = mysqli_fetch_array($result)){
			echo "<tr align=\"center\" class=\"list\">";	
			echo "<td class=\"list\" width=\"20%\" ><img src='biere/".$row['produit_name'].".png'>"	;		
			echo "<td class=\"list\" width=\"20%\" >".$row['produit_id']."</td>";
			echo "<td class=\"list\" width=\"20%\" >".$row['produit_name']."</td>";			
			echo "<td class=\"list\" width=\"20%\">".$row['item_quantity']."</td>";						
			echo "<td class=\"list\" width=\"20%\">".$row['item_quantity']*$row['item_price']."</td>";						
			echo "</tr>";			
		}	
		echo "</table>";	
		
	?>
	</div> <!-- fin contenu -->		
	<?php
	include 'footer.php';
?>
	</div><!-- fin contenant -->

</body>
</html>