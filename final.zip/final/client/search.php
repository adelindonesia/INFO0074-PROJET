<?php
		require_once 'config.php';
?>

<!--https://www.youtube.com/watch?v=lwgG_uIJYQM&ab_channel=DaniKrossing-->

<div class="produit-container">
<?php
	

	

	if(isset($_POST['submit-search'])){
		$search = mysqli_real_escape_string($con, $_POST['search']);
		$sql = "SELECT * FROM produit WHERE produit_name LIKE '%$search%' or produit_type LIKE '%search%' or produit_country LIKE '%$search%' or produit_design LIKE '%$search%' ";

		$result = mysqli_query($con, $sql);
		$queryResult = mysqli_num_rows($result);

		echo "<h1>There are ". $queryResult." results!</h1>";
		echo "<br>","<br>", "<br>";

		if ($queryResult > 0 ) {
			while ($row = mysqli_fetch_assoc($result)) {
				echo "<a href='product_detail.php?produit_name=".$row['produit_name']."'>
						<div class='produit_box'>
							<h2><c> ".$row['produit_name']."</c> </h2>
							<h2><img src='biere/".$row['produit_name'].".png'></h2>
							
						</div>
					</a>";
			}
		} else {
			echo"There are no result matching your research!";
		}
	}

?>
</div>
