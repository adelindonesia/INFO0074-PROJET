﻿<?php
session_start();
	//si le client n'est pas encore connecté, redirige vers la page login
	if (!(isset($_SESSION['email']))){
		header("Location: login.php");			
		exit();
	}
	
	require_once 'config.php';
	
	
	
	
	
	if (isset($_GET['produit_name'])){
		$query="SELECT produit_id, produit_name, produit_price, produit_volume, produit_type, produit_country, produit_alcohol, produit_design FROM produit WHERE produit_name='".$_GET['produit_name']."'";				
		$result = mysqli_query($con,$query);
		$row = mysqli_fetch_array($result);
		mysqli_close($con);	
	}else{ 
		header('Location: list_beer.php');
		exit();
	}

?>
<!DOCTYPE html>
<html>
<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" type="text/css" href="style.css">
        
		<title>Modification de bière</title>
	</head>
	
	<body>
			<header>
				<a href="index.php" ><img src="multimedia/Logo.jpg" alt="Logo : Groupe 72" class="header-brand"/></a>
				<nav>
					<ul>
						<li><a href="./list_beer.php">Produits</a></li>
						<li><a href="./contactez_nous.php">Contactez-nous</a></li>
						<li><a href="./login.php">Login</a></li>
						<li><a href="./.php">Gestion des commandes</a></li>
					</ul>
				</nav>
			</header>
	
	<main>
				<section class="index-banner">
					<div class="vertical-center">
						<h2> Bières </h2>
					</div>
				</section>
	
	<?php 
	
	if (isset($_SESSION['message'])){
		echo $_SESSION['message']; 
		unset($_SESSION['message']);
	}	
	?>
	
	<form name="product detail" action="product_detail.php?produit_name=<?php echo $_GET['produit_name'];?>" method="get">
	<table>
	<tr>
	
	<?php 
		echo "<td class=\"photo\" width=\"20%\"><img src='biere/".$row['produit_name'].".png' > </td>";
		?>
		<td>
			 
			Nom de la bière <br><br>
			Prix <br><br>
			Volume <br><br>
			Type de bière <br><br>
			Pays d'origine <br><br>
			Degré d'alcool <br><br>
		
		</td>
		<td>
			<?php echo "<td class=\"list\"  > 
		".$row['produit_name']." <br> <br> 
		 ".$row['produit_price']."  € <br> <br>
		 ".$row['produit_volume']." Cl <br> <br> 
		 ".$row['produit_type']." <br> <br> 
		".$row['produit_country']." % <br> <br>
		".$row['produit_alcohol']." <br> <br> </td>";
		echo "<td class=\"design\" width=\"60%\" > <center> <b>Description</b> </center> <br><br>".$row['produit_design']."</td>";	
		
		
			
			echo "</tr>"
			?>
	</table>
	</form>
	
	</main>
			
			<footer>
				<ul class="footer-links">
					<li><a href="/accueil.php">Home</a></li>
					<li><a href="/contactez_nous.php">Contact</a></li>
				</ul>
				<div class="footer-sm">
					<a href="">
						<img src="multimedia/fb_icone.jpg" alt="image facebook icone" />
						<img src="multimedia/insta_icone.jpg" alt="image instagram icone" />
						<img src="multimedia/linkedin_icone.jpg" alt="image linkedin icone" />
					</a>
				</div>
			</footer>
			
		</div>
    <script src="https://unpkg.com/ionicons@5.0.0/dist/ionicons.js"></script>
	</div>	
	</div> 	
</div>
</body>
</html>