<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">	
		<title>Accueil</title>
		<link rel="stylesheet" type="text/css" href="accueil.css">
		<?php
	include 'header.php';
?>
	
		

			

		<head>
  <script src="https://kit.fontawesome.com/c611c1c655.js" crossorigin="anonymous"></script>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale1.0">
	   <title>Contactez - nous</title>
	   <link rel="stylesheet" type="text/css" href="contact.css">	   
</head>

<nav>
<?php
 // définir les variables et valeurs nulles
$nomErr = $emailErr = $messageErr = "";
$nom = $email = $message = "";

  if (empty($_POST["nom"])) {
    $nomErr = "";
  } else {
    $nom = test_input($_POST["nom"]);
    // vérifier si le nom contient juste des lettres
    if (!preg_match("/^[a-zA-Z-' ]*$/",$nom)) {
      $nomErr = "invalide";
    }
  }

if (empty($_POST["email"])) {
    $emailErr = "";
  } else {
    $email = test_input($_POST["email"]);
    // vérifier  l'e-mail 
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $emailErr = " invalide";
    }
  }
  
   if (empty($_POST["message"])) {
    $message = "";
  } else {
    $message = test_input($_POST["message"]);
  }
  function test_input($data) 
  {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
}
 ?>
 
      <section class="contact">
	  <div class="content">
	      <h2>Contactez-nous</h2>
		  </div>
		  <div class="container">
		    <div class="contactInfo">
			  <div class="box">
			     <div class="icon"><i class="fas fa-map-marker"></i></div>
				  <div class="text">
				    <h3>Adresse</h3>
					<p>72 Rue de HEC,<br>Liège</p>
				</div>
			</div>
			<div class="box">
			   <div class="icon"><i class="fas fa-mobile"></i></div>
			   <div class="text">
			      <h3>Téléphone</h3>
				  <p>36 438299238</p>
				 </div>
				</div>
		    <div class="box">
			   <div class="icon"><i class="fas fa-at"></i></div>
			   <div class="text">
			      <h3>Email</h3>
				  <p>Groupe72@uliege.com</p>
				 </div>
				</div>
			 </div>
			
			 <div class="contactForm">
			     <h2>Envoyer le Message</h2>
				  <div class="inputBox">
				  <form action="contact.php" method="POST">
				    <input type="text" name="nom" required="required">
					<span class="error"><?php echo $nomErr;?>Nom Complet</span>
				</div>
				<div class="inputBox">
				    <input type="text" name="email" required="required">
					<span class="error"><?php echo $emailErr;?>Email</span>
				</div>
				<div class="inputBox">
				   <textarea required="required"></textarea>
				   <span class="error"><?php echo $messageErr;?>Saissisez votre Message ici...</span>
				</div>
				<div class="inputBox">
				  <input type="submit" name="sub_btn" value="envoyer">
			  </form>
		 </div>
	  

	<!-- fin menu -->
   </nav>
   
 
 <?php
	include 'footer.php';
?>
		
	</body>
</html>