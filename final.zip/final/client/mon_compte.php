﻿<?php
	session_start();
	//si l'utilisateur ne s'est pas connecté, il demande de s'authentifier
	if (!(isset($_SESSION['email']))){
		header("Location: login.php");			
		exit();
	}
	
	require_once 'config.php';
	
	
		
	//quand utilisateur clique sur le bouton mettre à jour
	if (isset($_POST['sub_btn'])){	
	
		$nom = $_POST['nom'];
		$prenom= $_POST['prenom'];
		$email= $_POST['email'];			
		$birthdate = $_POST['birthdate'];
        $GSM= $_POST['GSM'];
        $password= $_POST['password'];
		$passverif= $_POST['passverif'];
		
		$query = "UPDATE client SET client_surname='".$_POST["prenom"]."', client_firstname='".$_POST["nom"]."', client_birth='".$_POST["birthdate"]."', client_phone='".$_POST["GSM"]."', client_email='".$_POST["email"]."', client_password='".$_POST["password"]."' WHERE client_email='".$_SESSION['email']."'";
		
		//$query = "UPDATE client set (client_surname, client_firstname, client_email, client_birth, client_phone, client_password) VALUES ('$nom','$prenom','$email','$birthdate','$GSM','$password')";
		//$query = "UPDATE client SET client_surname='".$_POST["client_surname"]."', client_firstname='".$_POST["client_firstname"]."', client_password='".$_POST["client_password"]."', client_birth='".$_POST["client_birth"]."', client_phone='".$_POST["client_phone"]."', client_email='".$_POST["email"]."', WHERE client_id = '".$_GET['client_id']."'";
		if (!mysqli_query($con,$query)){
			$_SESSION['message'] = "<center class=\"alert\">Ne peut pas mettre à jour vote compte.</center> <br>";  //mettre le message dans la session
		}else{
			$_SESSION['message'] = "<center>Votre compte a été mise à jour.</center> <br>";	
		}		
		//rédiriger vers la même page
		mysqli_close($con);	
		header("Location: mon_compte.php");			
		exit();
	}
	
	
	if (isset($_SESSION['email'])){
		$query="SELECT client_surname, client_firstname, client_birth, client_phone, client_email, client_password FROM client WHERE client_email='".$_SESSION['email']."'";				
		$result = mysqli_query($con,$query);
		$row = mysqli_fetch_array($result);
		mysqli_close($con);	
	}else{ 
		header('Location: mon_compte.php');
		exit();
	
	


	}
?>

<!DOCTYPE html>
<html>
<meta charset="UTF-8">
<link rel="stylesheet" type="text/css" href="./style.css">


<head>
	<title>Modifier les données de votre compte</title>
</head>
<body>
<?php
	include 'header.php';
?>
	
	
	<div align="center"> <!-- début contenu -->
	<h2 align ="center"> Modifier les données de votre compte</h2> 
	
	<?php 
	//afficher le message de session et supprimer ce message de la variable session
	if (isset($_SESSION['message'])){
		echo $_SESSION['message']; 
		unset($_SESSION['message']);
	}	
	?>
	
	<form name="update_beer" action="mon_compte.php" method="post">
	<table align="center" width="20%" >
		<tr><td align="center">
			
			<input type="text" name="prenom" value="<?php echo $row['client_surname'];?>" required><br><br>
			<input type="text" name="nom" value="<?php echo $row['client_firstname'];?>" required><br><br>
		
			<input type="text" name="birthdate" value="<?php echo $row['client_birth'];?>" required><br><br>
			<input type="text" name="GSM" value="<?php echo $row['client_phone'];?>" required><br><br>
			<input type="text" name="email" value="<?php echo $row['client_email'];?>" required><br><br>
			<input type="text" name="password" value="<?php echo $row['client_password'];?>" required><br><br>
			<input type="submit" name="sub_btn" value="Mettre à jour">
			<input type="reset" name="res_btn" value="Réinitialiser">
			
		</td></tr>
		
	</table>
	</form>
	
	</div> <!-- fin contenu -->	
<?php
	include 'footer.php'
?>	
</div><!-- fin contenant -->
</body>
</html>