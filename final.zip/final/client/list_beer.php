﻿<?php

	session_start();
	//si customer n'est pas encore connecté, redirige vers la page login
	if (!(isset($_SESSION['email']))){
		header("Location: login.php");			
		exit();
	}
	
	require_once 'config.php';
	
	
	if (isset($_POST['sub_btn'])){
		
		if ($_POST['item_quantity'] <= 0){
			$_SESSION['message']="<center class=\"alert\">La quantité doit être positive!!!</center><br>";
			header('Location: list_beer.php');
			exit();
		}else{
			
//On va chercher les informations nécessaires pour le panier.
			
			$query = "SELECT * FROM produit WHERE produit_id='".$_POST['produit_id']."'";
			$result_produit = mysqli_query($con,$query);
			$row = mysqli_fetch_array($result_produit);
			
			$produit_id = $row['produit_id'];		
			$produit_name = $row['produit_name'];			
			$produit_price = $row['produit_price'];
			$item_quantity = $_POST['item_quantity'];
			
		
			$array_key = array_keys($_SESSION['panier']);
			if (in_array($row['produit_id'],$array_key)){  
				$produit_id = $row['produit_id'];
				$_SESSION['panier']["$produit_id"]['item_quantity'] = $_SESSION['panier']["$produit_id"]['item_quantity'] + $_POST['item_quantity'];
				$_SESSION['message'] = "<center>".$_POST['item_quantity']." Bière ".$row['produit_name']." a été rajoutée dans votre panier.</center><br>";
			}else{ 
				
				$panier_item = array($produit_id=>array('produit_id'=>$produit_id,'produit_name'=>$produit_name,'item_quantity'=>$item_quantity,'produit_price'=>$produit_price));
				$_SESSION['panier'] = array_merge($_SESSION['panier'],$panier_item);
				$_SESSION['message'] = "<center>".$_POST['item_quantity']."La Bière ".$row['produit_name']." a étté ajoutée dans le panier.</center><br>";
			}			
			
			header('Location: list_beer.php');
			exit();
		}	


		
	}
	
?>

<!DOCTYPE html>
<html>
<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" type="text/css" href="style.css">
        
		<title>Produits</title>
	</head>
	
	<body>
			
		<?php
	include 'header.php';
?>
			
<head>
	<title>Bières</title>
</head>
<body>


	<main>
				
					</div>
				
	
	<?php			
			
	if (isset($_SESSION['message'])){
		echo $_SESSION['message'];
		unset($_SESSION['message']);
	}
	
	
	$query = "SELECT * FROM produit";
	$result_produit = mysqli_query($con, $query);	
	echo "<table class=\"list\" align=\"center\">";	
	
	while($row = mysqli_fetch_array($result_produit)){
		echo "<tr>";
		echo "<td class=\"photo\" width=\"20%\"> <a href='product_detail.php?produit_name=".$row['produit_name']."'> <img src='biere/".$row['produit_name'].".png' > </a> </td>";
		echo "<td class=\"title\" width=\"10%\">  Nom de la Bière <br><br> Prix <br><br> Volume <br><br> Type de bière <br><br> Degré d'alcool <br><br> Pays d'origine <br><br> </td>";
		echo "<td class=\"list\" width=\"10%\" > 
		".$row['produit_name']." <br> <br> 
		 ".$row['produit_price']."  € <br> <br>
		 ".$row['produit_volume']." Cl <br> <br> 
		 ".$row['produit_type']." <br> <br> 
		".$row['produit_alcohol']." % <br> <br>
		".$row['produit_country']." <br> <br> </td>";
		echo "<td class=\"design\" width=\"30%\"> <center> <b>Description</b> </center> <br><br>".$row['produit_design']."</td>";	
		
		echo "<form name=\"add_cart_".$row['produit_id']."\" action=\"list_beer.php\" method=\"POST\">";		
		echo "<input type=\"hidden\" name=\"produit_id\" value=\"".$row['produit_id']."\">"; 
		echo "<td class=\"list\" width=\"10%\"><input type=\"number\" value=1 name=item_quantity></td>";
		echo "<td class=\"list\" width=\"20%\"><input type=\"submit\" name=\"sub_btn\" value=\"Ajouter\"></td>";
		echo "</form>";
		echo "</tr>";
	}	
	echo "</table>";	
	
	
	mysqli_close($con);		
	?>
	
	</main>
			
			
	</div>	
	<?php
	include 'footer.php';
?>
	</div> 	
	</div>
</body>
</html>