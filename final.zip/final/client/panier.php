﻿<?php

	session_start();
	//si customer n'est pas encore connecté, redirige vers la page login
	if (!(isset($_SESSION['email']))){
		header("Location: login.php");			
		exit();
	}
	
	require_once 'config.php';
	
	//Pour supprimer un item du panier
	if (isset($_GET['produit_id'])){
		$produit_id = $_GET['produit_id'];
		unset($_SESSION['panier'][$produit_id]);
		$_SESSION['message'] = "<center>Un item est supprimé</center>";
		//rédiriger vers la même page
		header('Location: panier.php');
		exit();
	}
	
	//Si le bouton Valider est cliqué et le panier est non vide, on insère les items dans la base de données
	if (isset($_POST['sub_btn']) and (sizeof($_SESSION['panier']) > 0)){
		//Pour inserer les items on a besoin du numéro order donc on insère un order 
		//$query_client = "SELECT * FROM client, client_id, client_name WHERE client_email=".$_SESSION['email']."";
		
		$client_id = $_GET['client_id'];
	
		
		$query = "INSERT INTO commande (commande_client) SELECT client_id FROM client WHERE client_email='".$_SESSION['email']."'";
		if (mysqli_query($con, $query)) {
			//pour récupérer le numéro order
			$commande_id = mysqli_insert_id($con);  

			//pour stocker le prix total
			$commande_price = 0;
			
			foreach($_SESSION['panier'] as $produit_id=>$panier_item){
				$query_item = "INSERT INTO item (item_produit, item_commande, item_price, item_quantity) VALUE (".$panier_item['produit_id'].",".$commande_id.",".$panier_item['produit_price'].",".$panier_item['item_quantity'].")"; 
				if (mysqli_query($con,$query_item)){
					unset($_SESSION['panier'][$produit_id]);
					//on calcule le prix total
					$commande_price = $commande_price + ($panier_item['item_quantity']*$panier_item['produit_price']);				
					$_SESSION['message'] = "<center>Votre commande est validée, et le numéro de votre commande est ".$commande_id."</center>";
				}else{
					$_SESSION['message'] = $_SESSION['message']."<center class=\"alert\">La bière ".$produit_name." ne peut pas être ajoutée!!!</center><br>";					
				}
			}			
			//mettre à jour le prix total de la commande
			$query = "UPDATE commande set commande_price=".$commande_price." WHERE commande_id=".$commande_id."";
			mysqli_query($con, $query);		//C'est mieux si on teste si la requête est bien exécuté ou non
			mysqli_close($con);				
		}else {
			$_SESSION['message'] = "<center class=\"alert\">La commande ne peut pas être ajoutée!!!</center>";						
		}		
				
		header('Location: panier.php');
		exit();
	}
?>
<?php
	include 'header.php'
?>
<!DOCTYPE html>
<html>
<meta charset="UTF-8">
<link rel="stylesheet" type="text/css" href="./style.css">
<head>
	<title>Mon Panier</title>
</head>
<body>

	
	<div> <!-- début contenu -->
	<h2 align="center">Mon Panier</h2>
	
	<?php			
	//afficher le message de la session
	if (isset($_SESSION['message'])){
		echo $_SESSION['message'];
		unset($_SESSION['message']);
	}
	//afficher le bouton valider
	echo "<form name=\"valide_panier\" action=\"panier.php\" method=\"post\">";
	echo "<input type=\"submit\" name=\"sub_btn\" value=\"Valider\">";
	echo "</form>";	
	echo "<br>";
	
	//afficher les éléments dans le panier
	echo "<table class=\"list\">";	
	
	foreach($_SESSION['panier'] as $produit_id=>$panier_item){
		echo "<tr>";
		echo "<td> <img src='biere/".$panier_item['produit_name'].".png' > ";
		echo "</td>";
		
		echo "<td class=\"title\" width=\"10%\">  Nom de la Bière <br><br> Quantité <br><br> Prix <br><br> Total  </td>";
		
		echo "<td class=\"title\" width=\"20%\"> 
		".$panier_item['produit_name']."<br><br>
		".$panier_item['item_quantity']."<br><br>
		".$panier_item['produit_price']."<br><br>
		".$panier_item['item_quantity']*$panier_item['produit_price']."<br><br>
		</td>";  // prix total pas item dans le panier
		echo "<td class=\"list\" width=\"5%\"><a href=panier.php?produit_id=".$produit_id.">
			<img src=\"delete.jpg\" alt=\"del\" height=\"30\"></a></td>";		
		echo "</tr>";
	}
	echo "</table>";		
	?>
	</div>
<?php
	include 'footer.php'
?>	
	</div>
</body>
</html>