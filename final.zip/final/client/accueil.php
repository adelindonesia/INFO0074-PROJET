<?php
	include 'header.php';
?>
<main>
	<!--Sous banner-->
	<div class="wrapper">
		<section class="index-links">
			<a href="./list_beer.php">
				<div>
					<h3>Produits</h3>
				</div>
			</a>
			<a href="./panier.php">
				<div>
					<h3>Panier</h3>
				</div>
			</a>
			<a href="./login.php">
				<div>
					<h3>Mon Compte</h3>
				</div>
			</a>
			<a href="./Contactez-nous.php">
				<div>
					<h3>Contactez-Nous</h3>
				</div>
			</a>
		</section>
	</div>
</main>
<?php
	include 'footer.php'
?>