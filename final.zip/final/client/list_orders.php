﻿<?php
	session_start();
	//demander à l'utilisateur de s'authentifier
	if (!$_SESSION['email']){
		header('Location: login.php');
		exit();
	}	
	
	require_once 'config.php';	
?>
<!DOCTYPE html>
<html>
<meta charset="UTF-8">
<link rel="stylesheet" type="text/css" href="./style.css">
<?php
	include 'header.php';
?>
<head>
	<title>Liste de vos commandes</title>
</head>
<body>

	
	<div align="center"> <!-- début contenu -->
	<h2 align="center"> Liste de vos commandes</h2>
	
	<?php
	//afficher les orders avec le nom et prénom du client
		$query = "SELECT commande.commande_id, commande.commande_client, client.client_surname, client.client_firstname, commande.commande_price, commande.commande_etat FROM commande, client WHERE client.client_id = commande.commande_client AND client.client_email='".$_SESSION['email']."' ORDER BY commande_id DESC";
	//$query = "SELECT commande_id, commande.client_id, client_firstname, client_lastname, commande_price FROM commande, client WHERE client.client_id = commande.commande_client AND client.client_email='".$_SESSION['email']."' ORDER BY commande_id DESC";				
	$result_commande = mysqli_query($con,$query);
	//afficher les enregistrements de la table
	echo "<table class=\"title\">";
	echo "<th>N. Commande</th><th>Client</th><th>Prix</th><th>Etat de la commande</th>";
	while($row = mysqli_fetch_array($result_commande)){
		echo "<tr align=\"center\" class=\"list\">";		
		echo "<td class=\"list\" width=\"20%\" ><a href=detail_order.php?commande_id=".$row['commande_id'].">".$row['commande_id']."</a></td>";  //lien pour avoir le produit en détail
		echo "<td class=\"list\" width=\"20%\">".$row['client_firstname']." ".$row['client_surname']."</td>";		
		echo "<td class=\"list\" width=\"20%\">".$row['commande_price']."</td>";
		echo "<td class=\"list\" width=\"20%\">".$row['commande_etat']."</td>";
		echo "</tr>";
	}
	echo "</table>";	
	mysqli_close($con);   //Il faut déconnecter du serveur
	?>
	</div> <!-- fin contenu -->	
<?php
	include 'footer.php';
?>	
	</div><!-- fin contenant -->
</body>
</html>