﻿<?php
session_start();
	if (!(isset($_SESSION['username']))){
		header("Location: login.php");		
		exit();
	}
	
	require_once 'config.php';
	
	
	if (isset($_POST['sub_btn'])){			
		$query = "UPDATE produit SET produit_id=".$_POST['produit_id'].", produit_name=".$_POST['produit_name'].", produit_price=".$_POST['produit_price'].", produit_volume=".$_POST['produit_volume'].", produit_type=".$_POST['produit_type'].", produit_country=".$_POST['produit_country'].", produit_alcohol=".$_POST['produit_alcohol'].", produit_design=".$_POST['produit_design']." WHERE produit_id = ".$_GET['produit_id']."";
		if (!mysqli_query($con,$query)){
			$_SESSION['message'] = "<center class=\"alert\">Impossible de mettre à jour la bière ".$_GET['produit_id']."!!!</center> <br>"; 
		}else{
			$_SESSION['message'] = "<center>La Bière ".$_GET['produit_id']." a été mise à jour!!</center> <br>";	
		}		
	
		mysqli_close($con);	
		header("Location: update_beer.php?produit_id=".$_GET['produit_id']);			
		exit();
	}
	
	
	if (isset($_GET['produit_id'])){
		$query="SELECT produit_id, produit_name, produit_price, produit_volume, produit_type, produit_country, produit_alcohol, produit_design FROM produit WHERE produit_id='".$_GET['produit_id']."'";				
		$result = mysqli_query($con,$query);
		$row = mysqli_fetch_array($result);
		mysqli_close($con);	
	}else{ 
		header('Location: list_beer.php');
		exit();
	}
	
?>
<!DOCTYPE html>
<html>
<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" type="text/css" href="style.css">
        
		<title>Modification de bière</title>
	</head>
	
	<body>
			<header>
				<a href="index.php" ><img src="multimedia/Logo.jpg" alt="Logo : Groupe 72" class="header-brand"/></a>
				<nav>
					<ul>
						<li><a href="./list_beer.php">Gestions des Produits</a></li>
						<li><a href="./contactez_nous.php">Contactez-nous</a></li>
						<li><a href="./login.php">Login</a></li>
						<li><a href="./.php">Gestion des commandes</a></li>
						<li><a href="./insert_beer.php">Ajouter une bière</a></li>
					</ul>
				</nav>
			</header>
	
	<main>
				<section class="index-banner">
					<div class="vertical-center">
						<h2> Modification de votre bière </h2>
					</div>
				</section>
	
	<?php 
	
	if (isset($_SESSION['message'])){
		echo $_SESSION['message']; 
		unset($_SESSION['message']);
	}	
	?>
	
	<form name="update_beer" action="update_beer.php?beer_id=<?php echo $_GET['produit_id'];?>" method="post">
	<table>
	<tr>
	
	<?php 
		echo "<td class=\"photo\" width=\"20%\"><img src='biere/".$row['produit_name'].".png' > </td>";
		?>
		<td>
			ID Bière <br><br> 
			Nom de la bière <br><br>
			Prix <br><br>
			Volume <br><br>
			Type de bière <br><br>
			Pays d'origine <br><br>
			Degré d'alcool <br><br>
			Description <br><br>
		</td>
		<td>
			<input type="text" name="produit_id" value="<?php echo $row['produit_id'];?>" disabled><br><br>
			<input type="text" name="produit_name" value="<?php echo $row['produit_name'];?>" required><br><br>
			<input type="number" name="produit_price" value="<?php echo $row['produit_price'];?>" required><br><br>
			<input type="number" name="produit_volume" value="<?php echo $row['produit_volume'];?>" required><br><br>
			<input type="text" name="produit_type" value="<?php echo $row['produit_type'];?>" required><br><br>
			<input type="text" name="produit_country" value="<?php echo $row['produit_country'];?>" required><br><br>
			<input type="number" name="produit_alcohol" value="<?php echo $row['produit_alcohol'];?>" required><br><br>
		</td>
		<td>
			<center> <b> Description </b><br><br>
			<input type="text"  name="produit_design" value="<?php echo $row['produit_design'];?>" required size="200" rows="3"> 
			</center></td>
		<td><input type="submit" name="sub_btn" value="Modifier">
			<input type="reset" name="res_btn" value="Réinitialiser"></td>
			</tr>
	</table>
	</form>
	</main>
			
			<footer>
				<ul class="footer-links">
					<li><a href="/accueil.php">Home</a></li>
					<li><a href="/contactez_nous.php">Contact</a></li>
				</ul>
				<div class="footer-sm">
					<a href="">
						<img src="multimedia/fb_icone.jpg" alt="image facebook icone" />
						<img src="multimedia/insta_icone.jpg" alt="image instagram icone" />
						<img src="multimedia/linkedin_icone.jpg" alt="image linkedin icone" />
					</a>
				</div>
			</footer>
			
		</div>
    <script src="https://unpkg.com/ionicons@5.0.0/dist/ionicons.js"></script>
	</div>	
	</div> 	
</div>
</body>
</html>