﻿<?php
	
	
	require_once 'config.php';
	}
?>
<!DOCTYPE html>
<html>
<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" type="text/css" href="style.css">
        
		<title>Gestions des clients</title>
	</head>
	
	<body>
			<header>
				<a href="index.php" ><img src="multimedia/Logo.jpg" alt="Logo : Groupe 72" class="header-brand"/></a>
				<nav>
					<ul>
						<li><a href="./list_beer.php">Gestion des produits</a></li>
						<li><a href="./contactez_nous.php">Contactez-nous</a></li>
						<li><a href="./login.php">Login</a></li>
						<li><a href="./.php">Gestion des commandes</a></li>
						<li><a href="./insert_beer.php">Ajouter une bière</a></li>
						<li><a href="./list_client.php">Gestion des clients</a></li>
					</ul>
				</nav>
			</header>
			
<body>


	<main>
				<section class="index-banner">
					<div class="vertical-center">
						<h2> Vos clients </h2>
					</div>
				</section>
				
	
	<?php
	if (isset($_SESSION['message'])){
		echo $_SESSION['message'];
		unset($_SESSION['message']);  
	}
	$result_client = mysqli_query($con, "SELECT * FROM client");
	echo "<table class=\"list\" align=\"center\">";
	
	while($row = mysqli_fetch_array($result_client)){
		echo "<tr>";
		echo "<td class=\"title\" width=\"10%\"> Numéro du client <br><br> Nom <br><br> Prénom <br><br> Date de naissance <br><br> sexe <br><br>  Téléphone <br><br> Email <br><br> </td>";
		echo "<td class=\"list\" width=\"10%\" > 
		".$row['client_id']." <br> <br> 
		 ".$row['client_surname']."  € <br> <br>
		 ".$row['client_firstname']." Cl <br> <br> 
		 ".$row['client_sex']." <br> <br> 
		".$row['client_birth']." % <br> <br>
		".$row['client_phone']." <br> <br>  		
		".$row['client_email']." <br> <br></td>";
		echo "<td class=\"design\" width=\"30%\"> <center> <b>Description</b> </center> <br><br>".$row['produit_design']."</td>"; 	// mettre un href pour aller vers les commandes des clients
		echo "<td class=\"list\" width=\"5%\"> 
		<center> <b>delete</b> <center><a href=list_beer.php?delete_beer=".$row['produit_id'].">  
			<img src=\"delete.jpg\" alt=\"del\" height=\"50\"></a></td></tr>";		// intéressant de pouvoir delete des clients ou pas? 
		echo "</tr>";
	}
	echo "</table>";		
				
	mysqli_close($con);	
	?>

	</main>
			
			<footer>
				<ul class="footer-links">
					<li><a href="/accueil.php">Home</a></li>
					<li><a href="/contactez_nous.php">Contact</a></li>
				</ul>
				<div class="footer-sm">
					<a href="">
						<img src="multimedia/fb_icone.jpg" alt="image facebook icone" />
						<img src="multimedia/insta_icone.jpg" alt="image instagram icone" />
						<img src="multimedia/linkedin_icone.jpg" alt="image linkedin icone" />
					</a>
				</div>
			</footer>
			
		</div>
    <script src="https://unpkg.com/ionicons@5.0.0/dist/ionicons.js"></script>
	</div>	
</div>
</body>
</html>