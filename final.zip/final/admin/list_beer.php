<?php
	 session_start();
	//tester si la session du client n'est pas encore terminée, on laisse le client accéder à l'application
	
	//si la session de l'utilisateur existe, il n'oblige pas de s'authentifier et il donne accès à l'application
	if (!(isset($_SESSION['username']))){
		header("Location: login.php");
		exit();
	}
	
	require_once 'config.php';

	if (isset($_GET['delete_produit'])){
		$produit_id = $_GET['delete_produit']; 
		$query = "DELETE FROM produit WHERE produit_id='$produit_id'";
		if (mysqli_query($con,$query)){
			$_SESSION['message'] = "<center>La Bière ".$produit_id." a été supprimée!</center> <br>";
		}else{
			$_SESSION['message'] = "<center>".mysqli_error($con).".</center> <br>";
		}		
		header("Location: list_beer.php");
		exit();
	}
?>
<!DOCTYPE html>
<html>
<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" type="text/css" href="style.css">
        
		<title>Produits</title>
	</head>
	
	<body>
			<header>
				<a href="index.php" ><img src="multimedia/Logo.jpg" alt="Logo : Groupe 72" class="header-brand"/></a>
				<nav>
					<ul>
						<li><a href="./list_beer.php">Gestion des produits</a></li>
						<li><a href="./contactez_nous.php">Contactez-nous</a></li>
						<li><a href="./login.php">Login</a></li>
						<li><a href="./.php">Gestion des commandes</a></li>
						<li><a href="./insert_beer.php">Ajouter une bière</a></li>
					</ul>
				</nav>
			</header>
			
<head>
	<title>Bières</title>
</head>
<body>


	<main>
				<section class="index-banner">
					<div class="vertical-center">
						<h2> Nos Bières </h2>
					</div>
				</section>
				
	
	<?php
	if (isset($_SESSION['message'])){
		echo $_SESSION['message'];
		unset($_SESSION['message']);  
	}
	$result_produit = mysqli_query($con, "SELECT * FROM produit");
	echo "<table class=\"list\" align=\"center\">";
	
	while($row = mysqli_fetch_array($result_produit)){
		echo "<tr>";
		echo "<td class=\"photo\" width=\"20%\"><img src='biere/".$row['produit_name'].".png' > </td>";
		echo "<td class=\"title\" width=\"10%\"> Code <br><br> Nom de la Bière <br><br> Prix <br><br> Volume <br><br> Type de bière <br><br> Degré d'alcool <br><br> Pays d'origine <br><br> </td>";
		echo "<td class=\"list\" width=\"10%\" ><a href=update_beer.php?produit_id=".$row['produit_id'].">".$row['produit_id']."</a> <br> <br> 
		".$row['produit_name']." <br> <br> 				
		 ".$row['produit_price']."  € <br> <br>				
		 ".$row['produit_volume']." Cl <br> <br> 			
		 ".$row['produit_type']." <br> <br>				 
		".$row['produit_alcohol']." % <br> <br>				
		".$row['produit_country']." <br> <br> </td>";
		echo "<td class=\"design\" width=\"30%\"> <center> <b>Description</b> </center> <br><br>".$row['produit_design']."</td>";	
		echo "<td class=\"list\" width=\"5%\">
		<center> <b>delete</b> <center><a href=list_beer.php?delete_produit=".$row['produit_id'].">
		
			<img src=\"delete.jpg\" alt=\"del\" height=\"50\"></a></td></tr>";		
		echo "</tr>";
	}
	echo "</table>";		
				
	mysqli_close($con);	
	?>
	
	</main>
			
			<footer>
				<ul class="footer-links">
					<li><a href="/accueil.php">Home</a></li>
					<li><a href="/contactez_nous.php">Contact</a></li>
				</ul>
				<div class="footer-sm">
					<a href="">
						<img src="multimedia/fb_icone.jpg" alt="image facebook icone" />
						<img src="multimedia/insta_icone.jpg" alt="image instagram icone" />
						<img src="multimedia/linkedin_icone.jpg" alt="image linkedin icone" />
					</a>
				</div>
			</footer>
			
		</div>
    <script src="https://unpkg.com/ionicons@5.0.0/dist/ionicons.js"></script>
	</div>	
</div>
</body>
</html>