﻿<?php
	session_start();
	if (!(isset($_SESSION['username']))){
		header("Location: login.php");		
		exit();
	}
	
	if (isset($_POST['sub_btn'])){				
		require_once 'config.php';
		
		$produit_id = $_POST["produit_id"];
		$produit_name= $_POST["produit_name"];
		$produit_price= $_POST["produit_price"];	
		$produit_volume= $_POST["produit_volume"];
		$produit_type= $_POST["produit_type"];
		$produit_alcohol= $_POST["produit_alcohol"];
		$produit_country= $_POST["produit_country"];
		$produit_design= $_POST["produit_design"];
		
		$query = "INSERT INTO produit (produit_id,produit_name,produit_price,produit_volume,produit_type,produit_alcohol,produit_country,produit_design) VALUES ('$produit_id','$produit_name','$produit_price','$produit_volume','$produit_type','$produit_alcohol','$produit_country','$produit_design')";
		if (mysqli_query($con, $query)){
			$_SESSION['message'] = "<center>La Bière ".$produit_id." a été ajoutée!!</center> <br>";				
		}else{
			$_SESSION['message'] = "<center class=\"alert\">La Bière ".$produit_id." existe déjà!!</center> <br>";			
		}		
		
		mysqli_close($con);	
		
		
		header("Location: insert_beer.php");			
		exit();
	}	
	

?>
<!DOCTYPE html>
<html>
<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" type="text/css" href="style.css">
        
		<title>Ajouter une bière</title>
	</head>
	
	<body>
			<header>
				<a href="index.php" ><img src="multimedia/Logo.jpg" alt="Logo : Groupe 72" class="header-brand"/></a>
				<nav>
					<ul>
						<li><a href="./list_beer.php">Gestion des produits</a></li>
						<li><a href="./contactez_nous.php">Contactez-nous</a></li>
						<li><a href="./login.php">Login</a></li>
						<li><a href="./.php">Gestion des commandes</a></li>
					</ul>
				</nav>
			</header>
<head>
	<title>Ajouter Bière</title>
</head>
<body>


	<main>
				<section class="index-banner">
					<div class="vertical-center">
						<h2> Ajouter une bière </h2>
					</div>
				</section>
	<?php 
	if (isset($_SESSION['message'])){
		echo $_SESSION['message']; 
		unset($_SESSION['message']);
	}
	?>

	<form name="insert_beer" action="insert_beer.php" " method="post">
	<table align=center width=100%>
		<tr>
		<td width=\"30%\" align=left class=title>
			ID Bière <br><br> 
			Nom de la bière <br><br>
			Prix <br><br>
			Volume <br><br>
			Type de bière <br><br>
			Degré d'alcool <br><br>
			
			Pays d'origine
			
			
		</td>

	<td width=\"30%\" align=right>
		<input type="text" name="produit_id" disabled><br><br>
		<input type="text" name="produit_name" required><br><br>
		<input type="number" name="produit_price" required><br><br>		
		<input type="number" name="produit_volume" required><br><br>	
		<input type="text" name="produit_type" required><br><br>	
		<input type="number" name="produit_alcohol" required><br><br>	
		<input type="text" name="produit_country" required>
	</td>	
	<td width=\"50%\" align=center> <b> Description  </b><br><br>
	<center><input type="text" name="produit_design" required size="200" rows="3"></center>
	<td width=\"20%\" align=center><input type="submit" name="sub_btn" value="Ajouter"><br><br>
	<input type="reset" name="res_btn" value="Réinitialiser"></td>
	</table>
	<div class="note"> Note: Pour ajouter une image, il suffit d'enregistrer cette dernière avec le nom correspondant dans le dossier bière. </div>
	</form>		
	</div> 
	
</main>
			
			<footer>
				<ul class="footer-links">
					<li><a href="/accueil.php">Home</a></li>
					<li><a href="/contactez_nous.php">Contact</a></li>
				</ul>
				<div class="footer-sm">
					<a href="">
						<img src="multimedia/fb_icone.jpg" alt="image facebook icone" />
						<img src="multimedia/insta_icone.jpg" alt="image instagram icone" />
						<img src="multimedia/linkedin_icone.jpg" alt="image linkedin icone" />
					</a>
				</div>
			</footer>
			
		</div>
    <script src="https://unpkg.com/ionicons@5.0.0/dist/ionicons.js"></script>
	</div>	
	
</div>
</body>
</html>