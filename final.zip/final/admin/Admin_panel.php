<?php session_start();
	//tester si la session du client n'est pas encore terminée, on laisse le client accéder à l'application
	
	//si la session de l'utilisateur existe, il n'oblige pas de s'authentifier et il donne accès à l'application
	if (!(isset($_SESSION['username']))){
		header("Location: login.php");
		exit();
	}

?>
<?php
	include 'header.php';
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">	
		<title>Client</title>
		<link rel="stylesheet" type="text/css" href="panel.css">
	</head>
	<body>
		
			<div class="sidebar">
				<nav>
	  				<ul>
	    			
	    				<li><a href="list_beer.php">Gérer les produits</a></li>
	    				<li><a href="list_client.php">Gérer les clients</a></li>
	   					<li><a href="signout.php">Déconnexion</a></li>
	  				</ul>
				</nav>
			</div>		
		
			
		</div>
			<?php
					include 'footer.php'
				?>
	</body>
	</html>
