-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 12, 2021 at 08:24 PM
-- Server version: 8.0.21
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `groupe_72`
--

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

DROP TABLE IF EXISTS `client`;
CREATE TABLE IF NOT EXISTS `client` (
  `client_id` int NOT NULL AUTO_INCREMENT,
  `client_surname` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `client_firstname` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `client_birth` varchar(10) NOT NULL,
  `client_phone` varchar(10) NOT NULL,
  `client_email` varchar(50) NOT NULL,
  `client_password` varchar(50) NOT NULL,
  PRIMARY KEY (`client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`client_id`, `client_surname`, `client_firstname`, `client_birth`, `client_phone`, `client_email`, `client_password`) VALUES
(1, 'jisoo', 'kim', '1995-01-03', '04222372', 'bpaolzgrouazgzr@gmail.com', '147258yy'),
(2, 'Xu', 'Hao', '1995-09-05', '042531420', 'hxj9595@gmail.com', '147258yy'),
(3, 'Madeleine', 'Hubin', '1987-04-06', '0484/93837', 'HMadel@projet.be', 'active7'),
(4, 'Marie', 'Marion', '1995-12-19', '0484/93837', 'Marion.marie@projet.be', 'fleur18'),
(5, 'Veronique', 'Poisson', '1965-08-26', '0484/93837', 'Poisson.Vero@projet.be', '123789A'),
(6, 'Henry', 'Gabriel', '1985-12-25', '0484/93837', 'Legrand@projet.be', 'machine'),
(7, 'Lois', 'Frank', '1977-06-05', '0484/93837', 'lois@projet.be', 'parcel2'),
(8, 'Markus', 'Laurent', '1996-12-18', '0484/93837', 'LaurMarkus@projet.be', '2021vie'),
(9, 'Lydia', 'Grimbergen', '1982-11-02', '0484/93837', 'Lydia@projet.be', 'moisson'),
(10, 'Joseph', 'Ferhat', '1997-04-02', '0484/93837', 'Ferhat@projet.be', 'turquie'),
(11, 'Pierre', 'Dujardin', '1952-07-12', '0484/93838', 'Du.Pierre@projet.be', 'azerty0'),
(12, 'Anne', 'Mael', '1963-03-03', '0484/93838', 'Maela@projet.be', 'qwerty8'),
(13, 'steve', 'Gruyere', '1991-09-19', '0484/93838', 'Gruyeres@projet.be', 'carbona'),
(14, 'Maxime', 'Chanteuse', '1967-10-07', '0484/93838', 'Chant.max@projet.be', 'album02'),
(15, 'Cesaire', 'Aime', '1981-05-23', '0484/93838', 'Aime.cesaire@projet.be', 'poesie'),
(16, 'Jacques', 'Martin', '1955-07-03', '0484/93838', 'Martins@projet.be', 'scoop'),
(17, 'Israel', 'Jacob', '1974-10-22', '0484/93838', 'Jacobis@projet.be', 'canaan'),
(18, 'Marceline', 'Rigolo', '2000-08-08', '0484/93838', 'Rigolo@projet.be', 'humour'),
(19, 'Payep', 'Annie', '1984-01-19', '0484/93838', 'Annie.p@projet.be', 'journal'),
(20, 'Bloom', 'Orlando', '1987-02-12', '0484/93838', 'Bloom@projet.be', 'pirates'),
(21, 'Kuhlman', 'Kathryn', '1959-06-09', '0484/93839', 'KKuhl@projet.be', 'windfir'),
(22, 'Osburn', 'Benson', '1966-07-28', '0484/93839', 'Tlos@projet.be', 'impact'),
(23, 'Taraji', 'Monique', '1988-11-12', '0484/93839', 'Monique.taraji@projet.be', 'empire'),
(24, 'Wilfried', 'Honey', '1951-06-27', '0484/93839', 'Wilfried@projet.be', 'beeswax'),
(25, 'Kitata', 'Dena', '1977-01-12', '0484/93839', 'Denakit@projet.be', 'worship'),
(26, 'Isabelle', 'Soleil', '1983-12-24', '0484/93839', 'Isabelle@projet.be', 'sunrays'),
(27, 'Amadeus', 'Wolfgang', '1998-01-01', '0484/93839', 'Wolf.Amadeus@projet.be', 'legend'),
(28, 'Larsson', 'Raoul', '1990-09-18', '0484/93839', 'RW@projet.be', 'attiek'),
(29, 'Sigrid', 'Vannessa', '2002-04-26', '0484/93839', 'Van.Sigrid@projet.be', 'raisons'),
(30, 'Francis', 'Ghislain', '1950-02-08', '0484/93839', 'GFrancis@projet.be', 'beeftek'),
(31, 'Alizee', 'Cornet', '2001-10-14', '0484/93840', 'Cornet@projet.be', 'tennis'),
(32, 'Jean', 'Dujardin', '1990-12-12', '0484/93840', 'Dujardin.Jean@projet.be', 'cinema'),
(33, 'Claire', 'Moulin', '1993-05-11', '0484/93840', 'Moulin.Claire@projet.be', 'muesli6'),
(34, 'Christophe', 'Beau', '1974-02-17', '0484/93840', 'ChristoBeau@projet.be', 'pruneau'),
(35, 'Jean', 'Martins', '1993-11-30', '0484/93840', 'Jean.Martins@projet.be', 'lavie12'),
(36, 'Fred', 'Renault', '1963-12-31', '0484/93840', 'Renault.Fred@projet.be', 'vitesse'),
(37, 'Jocelyne', 'Song', '1968-07-03', '0484/93840', 'SoJocelyne@projet.be', 'onions');

-- --------------------------------------------------------

--
-- Table structure for table `commande`
--

DROP TABLE IF EXISTS `commande`;
CREATE TABLE IF NOT EXISTS `commande` (
  `commande_id` int NOT NULL AUTO_INCREMENT,
  `commande_client` int NOT NULL,
  `commande_date` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `commande_price` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `commande_etat` varchar(50) NOT NULL,
  PRIMARY KEY (`commande_id`),
  KEY `panierclient` (`commande_client`)
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `commande`
--

INSERT INTO `commande` (`commande_id`, `commande_client`, `commande_date`, `commande_price`, `commande_etat`) VALUES
(81, 1, '', '', ''),
(82, 1, '', '', ''),
(83, 1, '', '', ''),
(84, 1, '', '', ''),
(85, 1, '', '1.9', ''),
(86, 1, '', '9.5', ''),
(87, 1, '', '1.9', '');

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

DROP TABLE IF EXISTS `item`;
CREATE TABLE IF NOT EXISTS `item` (
  `item_id` int NOT NULL AUTO_INCREMENT,
  `item_produit` int NOT NULL,
  `item_commande` int NOT NULL,
  `item_price` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `item_quantity` varchar(11) NOT NULL,
  PRIMARY KEY (`item_id`),
  KEY `itemproduit` (`item_produit`),
  KEY `itempanier` (`item_commande`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `item`
--

INSERT INTO `item` (`item_id`, `item_produit`, `item_commande`, `item_price`, `item_quantity`) VALUES
(16, 9, 81, '1.90', '1'),
(17, 11, 82, '2.20', '2'),
(18, 13, 82, '2.30', '2'),
(19, 9, 83, '1.90', '3'),
(20, 9, 84, '1.90', '1'),
(21, 9, 85, '1.90', '1'),
(22, 9, 86, '1.90', '5'),
(23, 9, 87, '1.90', '1');

-- --------------------------------------------------------

--
-- Table structure for table `produit`
--

DROP TABLE IF EXISTS `produit`;
CREATE TABLE IF NOT EXISTS `produit` (
  `produit_id` int NOT NULL AUTO_INCREMENT,
  `produit_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `produit_volume` decimal(11,2) NOT NULL,
  `produit_type` varchar(11) NOT NULL,
  `produit_country` varchar(50) NOT NULL,
  `produit_price` decimal(11,2) NOT NULL,
  `produit_alcohol` decimal(11,1) NOT NULL,
  `produit_design` varchar(500) NOT NULL,
  PRIMARY KEY (`produit_id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `produit`
--

INSERT INTO `produit` (`produit_id`, `produit_name`, `produit_volume`, `produit_type`, `produit_country`, `produit_price`, `produit_alcohol`, `produit_design`) VALUES
(9, 'Jupiler', '33.00', 'Pils blonde', 'Belgique', '1.90', '5.2', 'La Jupiler est une bière belge blonde de fermentation basse de type lager européen. Elle a été créée et fabriquée par la brasserie Piedbœuf devenue la brasserie Jupiler dans le village de Jupille-sur-Meuse, banlieue de Liège dont la bière tire son nom. \r\n'),
(11, 'Duvel', '33.00', 'Triple', 'Belgique', '2.20', '8.5', 'La Duvel est une bière blonde de fermentation haute brassée par la brasserie Duvel en Belgique. Elle représente 85 % de la production de la brasserie, qui produit également les Maredsous et la Vedett. C\'est une bière de type triple, dont le titre alcoolique est de 8,5 % en volume. \r\n'),
(12, 'Stella Artois', '25.00', 'Pils blonde', 'Belgique', '1.00', '5.2', 'La Stella Artois est une marque de bière blonde de fermentation basse de type pils brassée à la brasserie Artois à Louvain par le groupe Anheuser-Busch InBev. Ingrédients : malt, maïs, eau, houblon, levure Température idéale de service : 10 - 12°C parfois 3 °C \r\n'),
(13, 'Westmalle', '33.00', 'Triple', 'Belgique', '2.30', '9.5', 'La Westmalle est une bière trappiste brassée depuis le XIXᵉ siècle dans le village de Westmalle de la province d\'Anvers, à l\'Abbaye cistercienne de Westmalle. La brasserie Westmalle est la plus grande brasserie trappiste de Belgique. \r\n'),
(14, 'Chhimay Bleue', '33.00', 'Brune', 'Belgique', '2.50', '11.3', 'La Chimay Bleue est la plus forte et la plus complexe des bières trappistes de l\'abbaye de Notre Dame de Scourmont. Elle offre un bouquet d\'épices et un nez fruité, très caractéristique de la Chimay. En bouche, elle procure une longue amertume et traduit une torréfaction prononcée. \r\n'),
(15, 'Leffe', '33.00', 'Pils blonde', 'Belgique', '2.00', '6.6', 'La Leffe ou Abbaye de Leffe est une bière belge d\'Abbaye reconnue, créée en 1240 par les chanoines de l\'ordre de Prémontré de l\'abbaye Notre-Dame de Leffe et produite par la brasserie Artois à Louvain. \r\n'),
(16, 'Maes', '33.00', 'Pils blonde', 'Belgique', '1.80', '5.2', 'La Maes est une bière belge de type pils appartenant à Alken-Maes, filiale du groupe Heineken. \r\n'),
(17, 'Val-Dieu', '33.00', 'Pils blonde', 'Belgique', '2.20', '6.0', 'C\'est une bière fraîche et légère, modérément alcoolisée avec un fort caractère convivial.  Elle se boit aussi bien en apéritif que comme digestif. Elle peut également accompagner le repas.  Elle ne dessèche pas la bouche et développe un caractère agréable et amer en conclusion.  Une fraîcheur de départ la rendra plus agréable.  Elle gardera un léger manteau blanc tout au long de la dégustation \r\n'),
(18, 'Lindemans Kriek', '25.00', 'Lambic', 'Belgique', '1.70', '3.5', 'La kriek est une bière belge aromatisée avec des cerises acides (aussi appelées cerises Morello). Traditionnellement il s\'agit d\'une lambic, bière de fermentation spontanée, mais la dénomination n\'étant pas protégée toute bière aromatisée à la cerise peut être appelée kriek.\r\n'),
(19, 'Orval', '33.00', 'Pale ale', 'Belgique', '3.00', '6.2', 'L\'Orval est une bière à la production limitée. Elle se compose d\'eau de source, d\'orges deux rangs de printemps maltés, de houblons aromatiques et de sucre candi liquide. Elle va subir un concassage et mise en ébullition où sera rajouté le houblon. \r\n'),
(20, 'Grimbergen', '33.00', 'Quadruple', 'Belgique', '3.00', '10.0', 'Brassée à l\'origine pour célébrer les fêtes de pâques, la Grimbergen Optimo Bruno a rencontré un succès tel qu\'elle est désormais brassée tout au long de l\'année. Cette bière issue d\'une fermentation haute et qui titre tout de même 10° présente dans le verre une robe d\'un blond ambrée qui ne se pare d\'aucune mousse. \r\n'),
(21, 'Omer', '33.00', 'Pale ale', 'Belgique', '2.30', '8.0', 'La Omer Traditional Blond est une bière blonde titrée à 8% brassée par la Brasserie Bockor, brasserie située à Bellegem en Belgique et qui existe depuis 1892. \r\n'),
(22, 'Chouffe', '33.00', 'Pale ale', 'Belgique', '2.30', '8.0', 'La Chouffe est une bière blonde non filtrée, refermentée aussi bien en bouteille qu\'en fût.  Elle présente une belle mousse blanche avec de savoureuses senteurs épicées et fruitées. En bouche, la bière dévoile des touches fruitées, épicées et de coriandre.  \r\n'),
(23, 'La Trappe', '33.00', 'Pale ale', 'Belgique', '2.30', '6.5', 'La Trappe Blonde est une bière trappiste à la robe blonde dorée venue des Pays-Bas. C\'est une bière agréable, pur malt, fraîche et au caractère fruité.\r\n'),
(24, 'Kwak', '33.00', 'Pale ale', 'Belgique', '2.10', '8.4', 'Conçue à l\'origine comme un breuvage pour les cochers congelés, et traditionnellement servie dans son verre original du cocher, la Kwak est l\'une des bières les plus iconiques de Belgique. Versée dans un verre, elle nous dévoile une robe ambrée avec une tête blanche et moelleuse. Cette somptueuse Belgian Strong Ale dégage des arômes de malt au caramel, avec des abricots séchés et de la prune, pour une note séduisante de sucre de demerara.\r\n'),
(25, 'Triple Karmeliet', '33.00', 'Triple', 'Belgique', '2.10', '8.4', 'La bière Tripel Karmeliet est l\'un des grands classiques des bières belges. Selon la brasserie Bosteels, la recette utilisée serait la même depuis 1679. A l\'époque, la Karmeliet était alors produite au sein de l\'abbaye carmélite de Dendermonde. Bière de fermentation haute et refermentée en bouteille, elle présentait déjà à l\'époque la particularité d\'être produite à partir de trois céréales : l\'orge, le froment et l\'avoine. C\'est d\'ailleurs de ces ingrédients qu\'elle tire son nom.\r\n'),
(26, 'Kasteel', '33.00', 'Triple', 'Belgique', '2.60', '11.0', 'Avec cette Kasteel Tripel, venez découvrir la Reine des bières Triples de Belgique. Dorée et brillante, c\'est une bière de fermentation haute et refermentée en bouteille. Malgré ses 11°, elle est particulièrement douce et raffinée.\r\n'),
(27, 'Carlsberg', '33.00', 'Pils blonde', 'Danemark', '1.50', '5.6', 'Carlsberg est une compagnie brassicole danoise. Elle est le quatrième brasseur au monde, et est présente dans près de 140 pays. Le siège social est à Valby, Copenhague. La principale bière de la compagnie est la Carlsberg, mais le groupe brasse aussi la Tuborg, ainsi que de nombreuses bières locales. \r\n'),
(28, 'Corona', '33.00', 'Lager', 'Mexique', '1.80', '4.6', 'Corona est une marque de bière lager mexicaine produite dans plusieurs brasseries du Mexique par Grupo Modelo (propriété du groupe Anheuser-Busch InBev). \r\n'),
(29, 'Heineken', '33.00', 'Lager', 'Pays-Bas', '1.90', '5.0', 'Traduit de l\'anglais-Heineken Lager Beer, ou simplement Heineken est une bière blonde pâle avec 5% d\'alcool par volume produite par la brasserie néerlandaise Heineken N.V .. La bière Heineken est vendue dans une bouteille verte avec une étoile rouge. \r\n'),
(30, 'Barbar au miel', '33.00', 'Pale ale', 'Belgique', '2.70', '8.0', 'Avec la Barbãr, remontez aux sources de l\'art brassicole ! En effet, pendant des siècles, le seul sucre connu en Europe fut le miel. Il fut donc longtemps utilisé par les brasseurs pour élaborer ce qui deviendra plus tard la bière telle que nous la connaissons aujourd\'hui. \r\n'),
(31, 'Delirium', '33.00', 'Pale ale', 'Belgique', '2.60', '8.5', 'La Delirium Tremens a été brassée pour la première fois le 26 décembre 1988. Notre équipe de brasseurs a produit cette bière à la demande des Italiens. L\'authenticité de la Delirium réside dans les 3 levures différentes qu\'elle contient ainsi que dans sa bouteille originale en terre cuite. \r\n'),
(32, 'Paix Dieu', '33.00', 'Triple', 'Belgique', '3.10', '10.0', 'Cette bière était autrefois produite à l’abbaye de Paix Dieu, où le calendrier lunaire jouait un rôle central. Afin de conserver l’âme de l’abbaye, la Brasserie s’impose la rigueur de ne brasser que par pleine lune. \r\n'),
(33, 'Bush', '33.00', 'Pale ale', 'Belgique', '2.50', '10.5', 'Elle est brassée avec le même savoir faire qui a fait la renommée de ses consoeurs et en utilisant des levures propres à la brasserie et jalousement gardées secrètes. La Bush Blonde présente dans le verre une robe d\'un jaune pâle surmontée d\'un rocher mousseux conséquent. De ce chapeau, s\'échappent des arômes à la fois maltés, fruités et épicés avec des notes céréales, de pommes et d\'agrumes, ainsi que des touches évoquant la levure et les clous de girofle. \r\n'),
(34, 'Tsingtao', '33.00', 'Pale lager', 'Chine', '2.70', '4.7', 'Tsingtao ou Qingdao, est une entreprise brassicole en Chine implantée dans la ville de Qingdao qui produit la bière du même nom. La Tsingtao est la bière chinoise la plus connue et est exportée dans de très nombreux pays, notamment la France, grâce aux communautés chinoises. \r\n'),
(35, 'Asahi', '33.00', 'Pale lager', 'Japon', '2.50', '5.0', 'Bière numéro un au Japon, Asahi Super Dry est issue d\'une sélection des meilleurs ingrédients. La technologie de filtration sur céramique fait de Asahi une bière sèche en bouche qui lui procure une qualité désaltérante non égalée.\r\n'),
(36, 'Sapporo', '33.00', 'Pale lager', 'Japon', '2.80', '4.9', 'Sapporo est la plus ancienne marque de bière au Japon puisqu\'elle date de 1876. Tout commença avec Seibei Nakagawa qui quitta le Japon à 17 ans pour l\'Allemagne où il apprit le métier de brasseur, ce qu\'il met en pratique chez lui en 1876 en tant que premier maître brasseur de Sapporo. \r\n'),
(37, 'Cass', '33.00', 'Pale lager', 'Corée du Sud', '2.60', '4.5', 'Une bouteille en verre de la fameuse bière coréenne CASS, bière blonde légère idéal pour se rafraichir lors de chaudes journées d\'été. \r\n'),
(38, 'Taiwan beer', '33.00', 'Pale lager', 'Taïwan', '2.30', '4.5', 'La Taïwan Beer est la première bière brassée sur l\'île de Taïwan, et aujourd\'hui la seule marque de bière notable. Cette bière est disponible à l\'export de façon confidentielle jusqu\'en 2008. Puis en décembre de cette année la brasserie obtient une licence d\'exportation vers la Chine continentale.\r\n'),
(39, 'Singha', '33.00', 'Pale lager', 'Thaïlande', '2.60', '5.0', 'La Singha est une bière thaïlandaise blonde. Cette lager titrant à 5° d\'alcool est la plus ancienne (créée en 1933) et la plus populaire du pays. La bière Singha est une bière de type pils à fermentation basse, conçue par la brasserie Pathumthani en Thaïlande. \r\n');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `commande`
--
ALTER TABLE `commande`
  ADD CONSTRAINT `commande_ibfk_1` FOREIGN KEY (`commande_client`) REFERENCES `client` (`client_id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Constraints for table `item`
--
ALTER TABLE `item`
  ADD CONSTRAINT `item_ibfk_1` FOREIGN KEY (`item_commande`) REFERENCES `commande` (`commande_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `item_ibfk_2` FOREIGN KEY (`item_produit`) REFERENCES `produit` (`produit_id`) ON DELETE RESTRICT ON UPDATE RESTRICT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
